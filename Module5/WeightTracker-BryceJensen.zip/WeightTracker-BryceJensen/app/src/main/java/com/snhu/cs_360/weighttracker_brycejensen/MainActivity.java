package com.snhu.cs_360.weighttracker_brycejensen;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    ArrayList<WeightModel> weightModels = new ArrayList<>();

    TextView textDate;
    TextView textWeight;
    MaterialButton bSelectDate;
    MaterialButton bSelectWeight;
    FloatingActionButton addWeight_FAB;
    Dialog addWeightDialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        Toolbar toolbarMain = (Toolbar) findViewById(R.id.toolbarMain);
        setSupportActionBar(toolbarMain);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerWeightData);

        setUpWeightModels();

        // must be after setUpWeightModels()
        Weight_RecyclerViewAdapter adapter = new Weight_RecyclerViewAdapter(this, weightModels);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Add Weight stuff
        addWeight_FAB = findViewById(R.id.fabAddWeight);
        textDate = findViewById(R.id.tvDate);
        textWeight = findViewById(R.id.tvWeight);
        bSelectDate = findViewById(R.id.select_date_button);
        bSelectWeight = findViewById(R.id.select_weight_button);
        addWeightDialog = new Dialog(this);

        addWeight_FAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showaddWeightPopup();
            }
        });

        bSelectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCalendarPopup();
            }
        });

    }

    /**
     * creates the Weight models for the fake data in strings.xml
     */
    private void setUpWeightModels() {
        String[] weights = getResources().getStringArray(R.array.weights);
        String[] dates = getResources().getStringArray(R.array.dates);
        String[] PlusMinus = getResources().getStringArray(R.array.PlusMinus);

        for (int i = 0; i<weights.length; i++) {
            weightModels.add(new WeightModel(weights[i],
                    dates[i],
                    PlusMinus[i]));
        }
    }

    /**
     * Displays the menu items in the Toolbar
     * @param menu The options menu in which you place your items.
     *
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    /**
     * Shows the addWeight Dialog
     */
    public void showaddWeightPopup() {
        addWeightDialog.setContentView(R.layout.fragment_add_weight_popup);

        // To close the add weight dialog
        ConstraintLayout toClose = addWeightDialog.findViewById(R.id.toCloseConstraint);
        toClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeightDialog.dismiss();
            }
        });
        addWeightDialog.show();
    }

    /**
     * opens the Select Date popup
     */
    private void openCalendarPopup() {
        Calendar initialDate = Calendar.getInstance();

        DatePickerDialog dialogDate = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                textDate.setText(month + "/" + dayOfMonth + "/" + year);
            }
        }, initialDate.get(Calendar.YEAR), initialDate.get(Calendar.MONTH), initialDate.get(Calendar.DAY_OF_MONTH));

        dialogDate.show();
    }
}